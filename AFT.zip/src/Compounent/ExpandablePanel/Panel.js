import React from "react";
import { Row, Col } from "react-bootstrap";

const Panel = ({ item }) => {
  return (
    <td colSpan="17" style={{ backgroundColor: "rgb(16, 17, 67)" }}>
      <Row className="panel">
        {Object.keys(item).map((key, index) => {
          // if key is number then return null
          if (Number(key) || key === "0") return null;
          return (
            <Col
              xs={12}
              md={6}
              lg={6}
              key={index}
              className="px-5 d-flex align-items-center justify-content-start"
            >
              <div className="py-2">
                <span
                  className="fw-bold"
                  style={{ color: "rgb(185, 54, 245)" }}
                >
                  {key}{" "}
                </span>
                :
                <span className="" style={{ color: "rgb(196, 70, 255)" }}>
                  {" "}
                  {item[key]}
                </span>
              </div>
            </Col>
          );
        })}
      </Row>
    </td>
  );
};

export default Panel;
