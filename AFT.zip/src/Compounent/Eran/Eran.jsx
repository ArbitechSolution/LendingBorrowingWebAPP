import React from "react";
import Stake from "../Stake/Stake";

function Eran() {
  return (
    <div>
      <Stake />
    </div>
  );
}

export default Eran;
